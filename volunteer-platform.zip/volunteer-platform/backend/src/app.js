import express from "express";

const app =express();
import userRouter from "./router/user_router.js";
import postRouter from "./router/post_router.js";

app.use(express.json());
app.use("/api/users",userRouter);
app.use("/api/posts",postRouter);
export default app;