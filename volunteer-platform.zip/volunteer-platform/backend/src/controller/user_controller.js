import {User} from '../models/user_model.js';
const registerUser = async (res,req) => {
    try {
        const {username,password,email} = res.body;

        if(!username || !password || !email) {
            return res.status(400).json({message: 'All fields are required'});
        }

        const existingUser = await User.findOne({username});
        if(existingUser) {
            return res.status(400).json({message: 'User already exists'});
        }

        const newUser = new User({username,password,email: email.toLowerCase()});
        await newUser.save();

        res.status(201).json({message: 'User created successfully'});
    } catch (error) {
        res.status(500).json({message: 'Error creating user', error});
    }

};
export{registerUser};
