import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
    {
        username:{
            type:String,
            required: true,
            unique: true,
            lowercase: true,
            trim: true,
            minLength:1,
            maxLength:50
        },
        password:{
            type: String,
            required : true,
            minLength:6,
            maxLength: 50
        },
        email:{
            type:String,
            required: true,
            unique: true,
            lowercase: true,
            trim: true,            
        }
    },
    {
        timestamps:true
    }
);
export const User =  mongoose.model("User",userSchema);